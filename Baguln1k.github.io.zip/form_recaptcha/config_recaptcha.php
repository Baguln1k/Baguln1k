<!-- https://www.google.com/recaptcha/admin#site/ -->
<?php
$config_recaptcha = array(
	'public_key' => '6LddAkAUAAAAACX67JRWDYcl8s9-iuXIhEPGrsi8',
	'private_key' => '6LddAkAUAAAAAPNESLchRJMKbXo_1klPKDUjd2oE'
);
?>